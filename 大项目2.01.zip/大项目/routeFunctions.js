// ========== 路线分析相关 ==========
import { viewer } from './cesiumInit.js';

let routeMode = null;
let startCoord = null;
let endCoord = null;
let startPointEntity = null;
let endPointEntity = null;
let routeEntity = null;

document.getElementById('setStart')?.addEventListener('click', () => { routeMode = 'start'; });
document.getElementById('setEnd')?.addEventListener('click', () => { routeMode = 'end'; });

document.getElementById('confirmRoute')?.addEventListener('click', async () => {
    if (!startCoord || !endCoord) {
        alert("请先选择起点和终点！");
        return;
    }
    const origin = `${startCoord.lon},${startCoord.lat}`;
    const destination = `${endCoord.lon},${endCoord.lat}`;
    try {
        const res = await fetch(`http://127.0.0.1:8000/api/route?origin=${origin}&destination=${destination}`);
        const data = await res.json();
        if (!data.coords) {
            alert("后端返回异常：" + (data.error || "未知错误"));
            return;
        }
        // 删除旧路线
        if (routeEntity) viewer.entities.remove(routeEntity);
        // 添加新路线
        routeEntity = viewer.entities.add({
            polyline: {
                positions: Cesium.Cartesian3.fromDegreesArray(data.coords),
                width: 5,
                material: Cesium.Color.RED,
                clampToGround: true
            }
        });
        viewer.zoomTo(routeEntity);
        // 显示路程信息
        const minutes = Math.round(data.duration / 60);
        const kilometers = (data.distance / 1000).toFixed(2);
        document.getElementById("routeInfo").innerText = `预计用时：${minutes} 分钟，距离：${kilometers} 公里`;
    } catch (error) {
        alert("请求失败：" + error);
        console.error(error);
    }
});

viewer.screenSpaceEventHandler.setInputAction(click => {
    let cartesian = viewer.scene.pickPosition(click.position);
    if (!cartesian) {
        cartesian = viewer.camera.pickEllipsoid(click.position, viewer.scene.globe.ellipsoid);
    }
    if (!cartesian || !routeMode) return;
    const cartographic = Cesium.Cartographic.fromCartesian(cartesian);
    const lon = Cesium.Math.toDegrees(cartographic.longitude);
    const lat = Cesium.Math.toDegrees(cartographic.latitude);
    const pos = Cesium.Cartesian3.fromDegrees(lon, lat);

    if (routeMode === 'start') {
        startCoord = { lon, lat };
        document.getElementById('startInput').value = `${lon.toFixed(6)}, ${lat.toFixed(6)}`;
        // 删除旧起点
        if (startPointEntity) viewer.entities.remove(startPointEntity);
        startPointEntity = viewer.entities.add({
            position: pos,
            point: { pixelSize: 10, color: Cesium.Color.GREEN },
            label: { text: "起点", font: "14px sans-serif", pixelOffset: new Cesium.Cartesian2(0, -20) }
        });
    } else if (routeMode === 'end') {
        endCoord = { lon, lat };
        document.getElementById('endInput').value = `${lon.toFixed(6)}, ${lat.toFixed(6)}`;
        // 删除旧终点
        if (endPointEntity) viewer.entities.remove(endPointEntity);
        endPointEntity = viewer.entities.add({
            position: pos,
            point: { pixelSize: 10, color: Cesium.Color.BLUE },
            label: { text: "终点", font: "14px sans-serif", pixelOffset: new Cesium.Cartesian2(0, -20) }
        });
    }
    routeMode = null;
}, Cesium.ScreenSpaceEventType.LEFT_CLICK);

// ========== POI展示与分析 ==========
const poiPinBuilder = new Cesium.PinBuilder();
const poiInfoBox = document.getElementById('customInfoBox');
const poiEntityInfoMap = new Map();
let poiLastSelected = null;
let poiEditingPoint = null;
let poiBufferEntity = null;
let poiBufferPolygonCoords = null;
let poiAllShopData = [];
let poiDensityEntities = [];
let poiEntities = [];
let poiDensityVisible = false;
let poiVisible = true;
let poiBufferVisible = false;

// 加载POI数据
fetch('杭州餐饮POI.json')
  .then(response => response.json())
  .then(data => {
    poiAllShopData = data;
    data.forEach(item => {
      const defaultIcon = poiPinBuilder.fromText('🍴', Cesium.Color.RED, 32).toDataURL();
      const highlightIcon = poiPinBuilder.fromText('🍴', Cesium.Color.YELLOW, 40).toDataURL();
      const entity = viewer.entities.add({
        id: Cesium.createGuid(),
        name: item.name,
        position: Cesium.Cartesian3.fromDegrees(item.lon, item.lat),
        billboard: {
          image: defaultIcon,
          verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
          heightReference: Cesium.HeightReference.CLAMP_TO_GROUND
        }
      });
      poiEntityInfoMap.set(entity.id, { item, defaultIcon, highlightIcon });
      poiEntities.push(entity);
    });
    viewer.zoomTo(viewer.entities);
  });

// POI显示/隐藏
document.getElementById('togglePoiBtn')?.onclick = function() {
  poiVisible = !poiVisible;
  poiEntities.forEach(e => e.show = poiVisible);
  this.textContent = poiVisible ? "隐藏数据点" : "显示数据点";
};

// POI点击弹窗与编辑
viewer.screenSpaceEventHandler.setInputAction(evt => {
  // 路线选点优先
  if (routeMode) return; // 路线选点时不处理POI

  const picked = viewer.scene.pick(evt.position);
  if (poiLastSelected) {
    const info = poiEntityInfoMap.get(poiLastSelected.id);
    poiLastSelected.billboard.image = info.defaultIcon;
    poiLastSelected = null;
  }
  if (Cesium.defined(picked) && picked.id) {
    const data = poiEntityInfoMap.get(picked.id.id);
    if (data) {
      picked.id.billboard.image = data.highlightIcon;
      poiLastSelected = picked.id;
      const categories = data.item.type
        ? data.item.type.split(';').filter(Boolean).join(' / ')
        : '未知';
      const region = data.item.adname || '未知';
      poiInfoBox.innerHTML = `
        <h3>${data.item.name}</h3>
        <p><strong>类别：</strong>${categories}</p>
        <p><strong>区域：</strong>${region}</p>
        <p><strong>地址：</strong>${data.item.address}</p>
        <p><strong>电话：</strong>${data.item.tel && data.item.tel.length ? data.item.tel : '暂无'}</p>`;
      poiInfoBox.style.display = 'block';
      poiEditingPoint = { lon: data.item.lon, lat: data.item.lat };
      document.getElementById('editBox').style.display = 'block';
      document.getElementById('shopCountResult').textContent = '';
      return;
    }
  }
  poiInfoBox.style.display = 'none';
  document.getElementById('editBox').style.display = 'none';
  poiEditingPoint = null;
  document.getElementById('shopCountResult').textContent = '';
}, Cesium.ScreenSpaceEventType.LEFT_CLICK);

// POI缓冲区按钮
document.getElementById('toggleBufferBtn')?.onclick = function() {
  if (!poiBufferVisible) {
    if (!poiEditingPoint) return;
    const radius = parseFloat(document.getElementById('bufferRadius').value) || 200;
    axios.post('http://127.0.0.1:8000/buffer', {
      lon: poiEditingPoint.lon,
      lat: poiEditingPoint.lat,
      radius: radius
    }).then(res => {
      if (poiBufferEntity) {
        viewer.entities.remove(poiBufferEntity);
        poiBufferEntity = null;
      }
      const coords = res.data.coordinates;
      poiBufferPolygonCoords = coords;
      const flat = [];
      coords.forEach(c => { flat.push(c[0], c[1]); });
      poiBufferEntity = viewer.entities.add({
        polygon: {
          hierarchy: Cesium.Cartesian3.fromDegreesArray(flat),
          material: Cesium.Color.BLUE.withAlpha(0.3),
          outline: true,
          outlineColor: Cesium.Color.BLUE
        }
      });
      poiBufferVisible = true;
      this.textContent = "删除缓冲区";
      document.getElementById('shopCountResult').textContent = '';
    }).catch(() => alert('缓冲区计算失败'));
  } else {
    if (poiBufferEntity) {
      viewer.entities.remove(poiBufferEntity);
      poiBufferEntity = null;
    }
    poiBufferPolygonCoords = null;
    poiBufferVisible = false;
    this.textContent = "计算缓冲区";
    document.getElementById('shopCountResult').textContent = '';
  }
};

// 计算缓冲区内店家数量
document.getElementById('countShopBtn')?.onclick = function() {
  if (!poiBufferPolygonCoords || !poiAllShopData.length) {
    document.getElementById('shopCountResult').textContent = '请先生成缓冲区';
    return;
  }
  function pointInPolygon(lon, lat, polygon) {
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i][0], yi = polygon[i][1];
      const xj = polygon[j][0], yj = polygon[j][1];
      const intersect = ((yi > lat) !== (yj > lat)) &&
        (lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-12) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }
  let count = 0;
  for (const shop of poiAllShopData) {
    if (shop.lon && shop.lat && pointInPolygon(Number(shop.lon), Number(shop.lat), poiBufferPolygonCoords)) {
      count++;
    }
  }
  document.getElementById('shopCountResult').textContent = `数量: ${count}`;
};

// 店家数量分布图
document.getElementById('showDensityBtn')?.onclick = function() {
  if (poiDensityVisible) {
    poiDensityEntities.forEach(e => viewer.entities.remove(e));
    poiDensityEntities = [];
    poiDensityVisible = false;
    this.textContent = "显示店家数量分布图";
    return;
  }
  if (!poiAllShopData.length) {
    alert('无店家数据');
    return;
  }
  const lons = poiAllShopData.map(s => Number(s.lon));
  const lats = poiAllShopData.map(s => Number(s.lat));
  const minLon = Math.min(...lons), maxLon = Math.max(...lons);
  const minLat = Math.min(...lats), maxLat = Math.max(...lats);
  const gridX = 10, gridY = 10;
  const stepLon = (maxLon - minLon) / gridX;
  const stepLat = (maxLat - minLat) / gridY;
  let maxCount = 0;
  const gridCounts = [];
  for (let i = 0; i < gridX; i++) {
    for (let j = 0; j < gridY; j++) {
      const left = minLon + i * stepLon;
      const right = left + stepLon;
      const bottom = minLat + j * stepLat;
      const top = bottom + stepLat;
      const count = poiAllShopData.filter(s =>
        Number(s.lon) >= left && Number(s.lon) < right &&
        Number(s.lat) >= bottom && Number(s.lat) < top
      ).length;
      gridCounts.push({i, j, left, right, bottom, top, count});
      if (count > maxCount) maxCount = count;
    }
  }
  function getColor(count) {
    if (maxCount === 0) return Cesium.Color.LIGHTGRAY.withAlpha(0.2);
    const ratio = count / maxCount;
    if (ratio < 0.2) return Cesium.Color.BLUE.withAlpha(0.3);
    if (ratio < 0.4) return Cesium.Color.GREEN.withAlpha(0.3);
    if (ratio < 0.7) return Cesium.Color.YELLOW.withAlpha(0.3);
    return Cesium.Color.RED.withAlpha(0.4);
  }
  gridCounts.forEach(cell => {
    if (cell.count === 0) return;
    const rect = [
      cell.left, cell.bottom,
      cell.right, cell.bottom,
      cell.right, cell.top,
      cell.left, cell.top
    ];
    const entity = viewer.entities.add({
      polygon: {
        hierarchy: Cesium.Cartesian3.fromDegreesArray(rect),
        material: getColor(cell.count),
        outline: true,
        outlineColor: Cesium.Color.BLACK,
        outlineWidth: 10,
      },
      label: {
        text: cell.count.toString(),
        font: "bold 16px sans-serif",
        fillColor: Cesium.Color.BLACK,
        style: Cesium.LabelStyle.FILL,
        showBackground: true,
        backgroundColor: Cesium.Color.WHITE.withAlpha(0.7),
        verticalOrigin: Cesium.VerticalOrigin.CENTER,
        horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
        pixelOffset: new Cesium.Cartesian2(0, 0),
        position: Cesium.Cartesian3.fromDegrees(
          (cell.left + cell.right) / 2,
          (cell.bottom + cell.top) / 2
        )
      },
      position: Cesium.Cartesian3.fromDegrees(
        (cell.left + cell.right) / 2,
        (cell.bottom + cell.top) / 2
      )
    });
    poiDensityEntities.push(entity);
  });
  poiDensityVisible = true;
  this.textContent = "隐藏店家数量分布图";
};

// 关闭编辑框
document.getElementById('closeEditBox')?.onclick = function() {
  document.getElementById('editBox').style.display = 'none';
  poiEditingPoint = null;
};

// 信息面板拖拽
(function() {
  let isDragging = false;
  let startX, startY, startLeft, startTop;
  const infoBox = document.getElementById('customInfoBox');
  infoBox.style.position = 'absolute';
  if (!infoBox.style.left) infoBox.style.left = 'auto';
  if (!infoBox.style.top) infoBox.style.top = 'auto';
  infoBox.addEventListener('mousedown', function(e) {
    if (e.target.id === 'closeInfoBoxBtn') return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = infoBox.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', function(e) {
    if (isDragging) {
      let newLeft = startLeft + (e.clientX - startX);
      let newTop = startTop + (e.clientY - startY);
      newLeft = Math.max(0, Math.min(window.innerWidth - infoBox.offsetWidth, newLeft));
      newTop = Math.max(0, Math.min(window.innerHeight - infoBox.offsetHeight, newTop));
      infoBox.style.left = newLeft + 'px';
      infoBox.style.top = newTop + 'px';
      infoBox.style.right = 'auto';
      infoBox.style.bottom = 'auto';
    }
  });
  document.addEventListener('mouseup', function() {
    isDragging = false;
    document.body.style.userSelect = '';
  });
})();

// 数据编辑面板拖拽
(function() {
  let isDragging = false;
  let startX, startY, startLeft, startTop;
  const infoBox = document.getElementById('editBox');
  infoBox.style.position = 'absolute';
  if (!infoBox.style.left) infoBox.style.left = 'auto';
  if (!infoBox.style.top) infoBox.style.top = 'auto';
  infoBox.addEventListener('mousedown', function(e) {
    if (e.target.id === 'BUTTON') return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = infoBox.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', function(e) {
    if (isDragging) {
      let newLeft = startLeft + (e.clientX - startX);
      let newTop = startTop + (e.clientY - startY);
      newLeft = Math.max(0, Math.min(window.innerWidth - infoBox.offsetWidth, newLeft));
      newTop = Math.max(0, Math.min(window.innerHeight - infoBox.offsetHeight, newTop));
      infoBox.style.left = newLeft + 'px';
      infoBox.style.top = newTop + 'px';
      infoBox.style.right = 'auto';
      infoBox.style.bottom = 'auto';
    }
  });
  document.addEventListener('mouseup', function() {
    isDragging = false;
    document.body.style.userSelect = '';
  });
})();

// ========== 路线缓冲区分析功能 ==========
let bufferEntity = null;
let originalPoiEntities = new Map();
let isAnalyzing = false;

document.getElementById('bufferAnalysis')?.onclick = function() {
    let panel = document.getElementById('bufferAnalysisPanel');
    panel.style.display = (panel.style.display === 'none' ? 'block' : 'none');
};

document.getElementById('startAnalysis')?.onclick = async function() {
    if (!routeEntity) {
        alert('请先进行路线分析！');
        return;
    }
    if (isAnalyzing) {
        alert('分析正在进行中！');
        return;
    }
    isAnalyzing = true;
    try {
        const routePositions = routeEntity.polyline.positions.getValue();
        const routeCoords = [];
        for (let i = 0; i < routePositions.length; i++) {
            const cartographic = Cesium.Cartographic.fromCartesian(routePositions[i]);
            const lon = Cesium.Math.toDegrees(cartographic.longitude);
            const lat = Cesium.Math.toDegrees(cartographic.latitude);
            routeCoords.push(`${lon},${lat}`);
        }
        const startCartographic = Cesium.Cartographic.fromCartesian(startPointEntity.position.getValue());
        const endCartographic = Cesium.Cartographic.fromCartesian(endPointEntity.position.getValue());
        const startPoint = `${Cesium.Math.toDegrees(startCartographic.longitude)},${Cesium.Math.toDegrees(startCartographic.latitude)}`;
        const endPoint = `${Cesium.Math.toDegrees(endCartographic.longitude)},${Cesium.Math.toDegrees(endCartographic.latitude)}`;
        const response = await fetch(`http://127.0.0.1:8000/api/buffer-analysis?route_coords=${routeCoords.join(';')}&start_point=${startPoint}&end_point=${endPoint}`);
        const data = await response.json();
        if (data.error) throw new Error(data.error);
        if (bufferEntity) viewer.entities.remove(bufferEntity);
        const coordinates = data.buffer_geometry.coordinates[0];
        const bufferPositions = [];
        for (const coord of coordinates) {
            bufferPositions.push(coord[0], coord[1], 0);
        }
        bufferEntity = viewer.entities.add({
            polygon: {
                hierarchy: new Cesium.PolygonHierarchy(
                    Cesium.Cartesian3.fromDegreesArrayHeights(bufferPositions)
                ),
                material: Cesium.Color.ORANGE.withAlpha(0.3),
                outline: true,
                outlineColor: Cesium.Color.ORANGE
            }
        });
        const poiInfoPanel = document.getElementById('poiInfoPanel');
        poiInfoPanel.innerHTML = '';
        originalPoiEntities.clear();
        viewer.entities.values.forEach(entity => {
            if (entity.billboard && entity.billboard.image) {
                originalPoiEntities.set(entity.id, {
                    visible: entity.show,
                    image: entity.billboard.image.getValue()
                });
            }
        });
        const bufferPoiAddresses = new Set(data.buffer_pois.map(poi => poi.address));
        viewer.entities.values.forEach(entity => {
            if (entity.billboard && entity.billboard.image) {
                const entityInfo = poiEntityInfoMap.get(entity.id);
                if (entityInfo && bufferPoiAddresses.has(entityInfo.item.address)) {
                    entity.show = true;
                    entity.billboard.image = poiPinBuilder.fromText('🍴', Cesium.Color.YELLOW, 40).toDataURL();
                } else {
                    entity.show = false;
                }
            }
        });
        data.buffer_pois.forEach(poi => {
            const poiItem = document.createElement('div');
            poiItem.className = 'poi-item';
            poiItem.innerHTML = `
                <h4>${poi.name}</h4>
                <p><strong>类型：</strong>${poi.type || '未知'}</p>
                <p><strong>地址：</strong>${poi.address || '未知'}</p>
                <p><strong>电话：</strong>${poi.tel || '未知'}</p>
            `;
            poiInfoPanel.appendChild(poiItem);
        });
        poiInfoPanel.style.display = 'block';
    } catch (error) {
        alert('分析失败：' + error.message);
        isAnalyzing = false;
    }
};

document.getElementById('endAnalysis')?.onclick = function() {
    if (!isAnalyzing) return;
    if (bufferEntity) {
        viewer.entities.remove(bufferEntity);
        bufferEntity = null;
    }
    originalPoiEntities.forEach((state, id) => {
        const entity = viewer.entities.getById(id);
        if (entity) {
            entity.show = state.visible;
            entity.billboard.image = state.image;
        }
    });
    document.getElementById('poiInfoPanel').style.display = 'none';
    isAnalyzing = false;
};


